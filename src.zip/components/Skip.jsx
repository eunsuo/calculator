import React from "react";

const Skip = () => {
    return <div>Skip</div>;
};

export default Skip;