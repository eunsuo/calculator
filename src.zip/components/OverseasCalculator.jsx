import React from "react";

const OverseasCalculator = () => {
    return <div>OverseasCalculator</div>;
};

export default OverseasCalculator;