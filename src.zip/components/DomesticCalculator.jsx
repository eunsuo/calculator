import React from "react";

const DomesticCalculator = () => {
    return <div>DomesticCalculator</div>;
};

export default DomesticCalculator;